import java.awt.Graphics;

public class Bank extends Sprite
{

	public Bank() 
	{
		super("bank.png");
		super.setX(300);
		super.setY(300);
	}
	public void updateImage (Graphics g)
	{
		super.updateImage(g);
	}



		

	

}
