
import java.awt.Graphics; 

public class Bank extends Sprite
{

	public Bank() 
	{
		super("Bank.png");
		// TODO Auto-generated constructor stub
		this.setX(300);
		this.setY(300);
	}
	
	public void updateImage(Graphics g)
	{
		super.updateImage(g);
	}
	
}
