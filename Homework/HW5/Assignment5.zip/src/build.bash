#!/bin/bash
set -u -e
javac Assignment3.java
java Assignment3
